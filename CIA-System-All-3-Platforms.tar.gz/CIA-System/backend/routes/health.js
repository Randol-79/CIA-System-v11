const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Integration health check
router.get('/integrations', async (req, res) => {
  try {
    res.json({
      postgres: { status: 'connected', latency: 5 },
      redis: { status: 'connected', latency: 2 },
      slack: { status: 'disabled', message: 'Placeholder tokens' },
      anthropic: { status: 'disabled', message: 'No API key configured' },
      accelo: { status: 'ready', message: 'Stub service' },
      fireflies: { status: 'ready', message: 'Stub service' },
      googleAnalytics: { status: 'ready', message: 'Stub service' }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;