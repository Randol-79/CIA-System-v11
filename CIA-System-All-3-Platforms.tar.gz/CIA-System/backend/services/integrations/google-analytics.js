const logger = require('../../utils/logger');

class GoogleAnalyticsService {
  constructor() {
    logger.info('Google Analytics service initialized (stub)');
  }

  async getMetrics(clientId) {
    return {};
  }
}

module.exports = GoogleAnalyticsService;