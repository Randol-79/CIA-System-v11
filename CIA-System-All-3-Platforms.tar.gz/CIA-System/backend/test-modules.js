// Quick test script to find which module is failing
console.log('1. Loading dotenv...');
require('dotenv').config();

console.log('2. Loading express...');
const express = require('express');

console.log('3. Loading logger...');
const logger = require('./utils/logger');

console.log('4. Loading database...');
const { sequelize, testConnection } = require('./config/database');

console.log('5. Loading health routes...');
const healthRoutes = require('./routes/health');

console.log('6. Loading client routes...');
const clientRoutes = require('./routes/clients');

console.log('7. Loading webhook routes...');
const webhookRoutes = require('./routes/webhooks');

console.log('8. Loading slack routes...');
const slackRoutes = require('./routes/slack');

console.log('9. Loading recommendation routes...');
const recommendationRoutes = require('./routes/recommendations');

console.log('10. Loading analytics routes...');
const analyticsRoutes = require('./routes/analytics');

console.log('11. Loading orchestrator...');
const OrchestratorService = require('./services/orchestrator');

console.log('12. Loading websocket...');
const WebSocketService = require('./services/websocket');

console.log('All modules loaded successfully!');
