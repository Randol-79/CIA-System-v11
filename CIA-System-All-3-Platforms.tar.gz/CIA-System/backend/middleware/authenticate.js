/**
 * Authentication Middleware
 * For now, just a pass-through. Add JWT validation later.
 */

const authenticate = (req, res, next) => {
  // TODO: Add JWT token validation
  next();
};

module.exports = authenticate;